#ifdef STM32G0xx
#include "stm32g0xx_ll_ucpd.c"
#endif
#ifdef STM32G4xx
#include "stm32g4xx_ll_ucpd.c"
#endif
